import { DynamoDBClient } from '@aws-sdk/client-dynamodb'
import { CognitoIdentityProviderClient, AdminCreateUserCommand } from '@aws-sdk/client-cognito-identity-provider'
import {
  DynamoDBDocumentClient,
  ScanCommand,
  GetCommand,
  PutCommand,
  DeleteCommand,
} from '@aws-sdk/lib-dynamodb'

const doc = DynamoDBDocumentClient.from(new DynamoDBClient({}))
const cognito = new CognitoIdentityProviderClient({})

const TABLES = {
  vehicles: process.env.VEHICLES_TABLE,
  rentals: process.env.RENTALS_TABLE,
}
const USER_POOL_ID = process.env.USER_POOL_ID
const DEFAULT_FEATURED_VEHICLES = new Set([
  'mercedes-amg-gt',
  'range-rover-sport',
  'rolls-royce-ghost',
])

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  }
}

export async function handler(event) {
  try {
    const method = event.requestContext?.http?.method ?? event.httpMethod
    const path = (event.rawPath ?? event.path ?? '').replace(/\/+$/, '')
    if (method === 'OPTIONS') {
      return {
        statusCode: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        },
        body: '',
      }
    }
    if (path === '/public/vehicles') {
      if (method !== 'GET') return json(405, { error: `Method not allowed: ${method}` })
      const { Items = [] } = await doc.send(new ScanCommand({ TableName: TABLES.vehicles }))
      const vehicles = Items.filter((vehicle) => !vehicle.archived)
      return json(200, vehicles.map(({ id, name, category, seats, rate, status, exteriorImage, featured }) => ({
        id, name, category, seats, rate, status, exteriorImage,
        featured: featured ?? DEFAULT_FEATURED_VEHICLES.has(id),
      })))
    }
    const publicVehicleMatch = path.match(/^\/public\/vehicles\/([^/]+)$/)
    if (publicVehicleMatch) {
      if (method !== 'GET') return json(405, { error: `Method not allowed: ${method}` })
      const id = decodeURIComponent(publicVehicleMatch[1])
      const { Item } = await doc.send(new GetCommand({ TableName: TABLES.vehicles, Key: { id } }))
      if (!Item || Item.archived) return json(404, { error: 'Vehicle not found' })
      return json(200, Item)
    }
    if (path === '/staff/invitations') {
      if (method !== 'POST') return json(405, { error: `Method not allowed: ${method}` })
      const groupsClaim = event.requestContext?.authorizer?.jwt?.claims?.['cognito:groups']
      let groups = []
      try { groups = JSON.parse(groupsClaim ?? '[]') } catch { groups = [] }
      if (!Array.isArray(groups) || !groups.includes('Admins')) return json(403, { error: 'Admin group membership required' })

      const { email = '' } = JSON.parse(event.body ?? '{}')
      const normalizedEmail = String(email).trim().toLowerCase()
      if (normalizedEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
        return json(400, { error: 'A valid email address is required' })
      }
      try {
        await cognito.send(new AdminCreateUserCommand({
          UserPoolId: USER_POOL_ID,
          Username: normalizedEmail,
          UserAttributes: [
            { Name: 'email', Value: normalizedEmail },
            { Name: 'email_verified', Value: 'true' },
          ],
          DesiredDeliveryMediums: ['EMAIL'],
        }))
        return json(201, { email: normalizedEmail })
      } catch (error) {
        if (error?.name === 'UsernameExistsException') return json(409, { error: 'An account already exists for this email' })
        throw error
      }
    }

    const match = path.match(/^\/(vehicles|rentals)(?:\/([^/]+))?$/)
    if (!match) return json(404, { error: `Unknown route: ${method} ${path}` })

    const [, resource, id] = match
    const TableName = TABLES[resource]

    if (id) {
      if (method === 'GET') {
        const { Item } = await doc.send(new GetCommand({ TableName, Key: { id } }))
        return Item ? json(200, Item) : json(404, { error: `${resource} item not found: ${id}` })
      }
      if (method === 'PUT' || method === 'POST') {
        const item = { ...JSON.parse(event.body ?? '{}'), id }
        await doc.send(new PutCommand({ TableName, Item: item }))
        return json(200, item)
      }
      if (method === 'DELETE') {
        await doc.send(new DeleteCommand({ TableName, Key: { id } }))
        return json(204, null)
      }
      return json(405, { error: `Method not allowed: ${method}` })
    }

    if (method === 'GET') {
      const { Items = [] } = await doc.send(new ScanCommand({ TableName }))
      return json(200, Items)
    }
    if (method === 'POST' || method === 'PUT') {
      const item = JSON.parse(event.body ?? '{}')
      if (!item.id) return json(400, { error: 'Body must include an id' })
      await doc.send(new PutCommand({ TableName, Item: item }))
      return json(200, item)
    }
    return json(405, { error: `Method not allowed: ${method}` })
  } catch (error) {
    console.error(error)
    return json(500, { error: 'Internal error', detail: String(error?.message ?? error) })
  }
}
